& ./build.ps1
$env:qmodName = "GorillaUtils"
& ./CreateQmod.ps1