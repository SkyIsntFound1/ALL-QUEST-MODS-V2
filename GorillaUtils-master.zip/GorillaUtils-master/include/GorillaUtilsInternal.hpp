#pragma once

namespace GorillaUtils
{
    void OnJoinedRoom();
    void OnLeftRoom();
}