& ./build.ps1
$env:qmodName = "SpaceMonke"
$env:module_id = "spacemonke"
& ./CreateQmod.ps1