& ./build.ps1
& adb push libs/arm64-v8a/libspacemonke.so /sdcard/Android/data/com.AnotherAxiom.GorillaTag/files/mods/libspacemonke.so

& adb shell am force-stop com.AnotherAxiom.GorillaTag
& adb shell am start com.AnotherAxiom.GorillaTag/com.unity3d.player.UnityPlayerActivity
& adb logcat -c
& adb logcat | Select-String "SpaceMonke"
