# Where-Gravity-Go
Gorilla Tag mod for Quest 1 &amp; 2.<br> While holding down the A button gravity will be set to whatever you chose in the watch 0 being no gravity 10 being twice the gravity.
