#pragma once

#include <string>

namespace MapLoader::RoomUtils
{
    void JoinModdedLobby(std::string gameMode);
}